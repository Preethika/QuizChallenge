console.log('getFilters');
export const getFilter = state => state.filterReducer.filters;