import List from './Components/List/List';
import './App.css';

function App() {
  return  <List />;
}

export default App;
